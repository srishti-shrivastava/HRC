package com.higradius;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.sql.*;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.gson.Gson;

/**
 * Servlet implementation class ViewCServlet
 */
public class ViewServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ViewServlet() {
        super();
        // TODO Auto-generated constructor stub
    }
    static final String JDBC_DRIVER = "com.mysql.jdbc.Driver";
    static final String DB_URL = "jdbc:mysql://localhost/h2h_internship";
    static final String USER = "root";
  	static final String PASS = "Roopa@516kiit";

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		response.setContentType("application/json");
	    response.setCharacterEncoding("UTF-8");
	    PrintWriter out = response.getWriter();
		
		String doc_id= request.getParameter("doc_id");
		List<Pojo1> list_users= new ArrayList<>();
		Connection conn = null;
		//Statement stmt = null;
		Statement statement=null;
		try {

			Class.forName(JDBC_DRIVER);
		    conn=DriverManager.getConnection(DB_URL,USER,PASS);
		    statement = conn.createStatement();
		      String query = "SELECT cust_number FROM invoice_details WHERE doc_id="+doc_id;
		      System.out.println(query);
		      ResultSet rs = statement.executeQuery(query);
		      String cust_number="";
		      if(rs.next()){
			      cust_number=rs.getString(1);
			   }
		      
		      System.out.println("\n\n**"+cust_number+"**\n\n");
		      
		      query = "SELECT name_customer,due_in_date,invoice_currency,total_open_amount,doc_id,document_create_date FROM invoice_details WHERE cust_number="+cust_number;
		      rs=statement.executeQuery(query);
		      while(rs.next()){
		    	  Pojo1 u=new Pojo1();
		    	  u.setCust_number(cust_number);
		    	  u.setName_customer(rs.getString(1));
		    	  u.setDue_in_date(rs.getDate(2));
		    	  u.setInvoice_currency(rs.getString(3));
		    	  u.setTotal_open_amount(rs.getDouble(4));
		    	  u.setDoc_id(rs.getLong(5));
		    	  u.setDocument_create_date(rs.getDate(6));
		    	  
		    	//set values in arraylist
	              System.out.println(Arrays.toString(list_users.toArray()));
	              list_users.add(u);
		      }
		      Gson gson = new Gson();
			String data = gson.toJson(list_users);
			   out.write(data.toString());
		      
		}catch(Exception e) {
			System.out.print("ERROR!");
			e.printStackTrace();
			
		}

		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}