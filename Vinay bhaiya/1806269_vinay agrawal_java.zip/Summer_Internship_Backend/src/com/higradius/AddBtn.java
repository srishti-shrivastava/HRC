package com.higradius;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
//import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
;
/**
 * Servlet implementation class AddDataServlet
 */
@WebServlet("/adddata")
public class AddBtn extends HttpServlet {
 private static final long serialVersionUID = 1L;
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AddBtn() {
        super();
        // TODO Auto-generated constructor stub
    }
 static final String JDBC_DRIVER = "com.mysql.jdbc.Driver";
  static final String DB_URL = "jdbc:mysql://localhost/h2h_internship";
  static final String USER = "root";
	static final String PASS = "Roopa@516kiit";
 public void doGet(HttpServletRequest  req, HttpServletResponse res) {
  java.sql.Date due_in_date;
  Pojo1 obj=new Pojo1();
  obj.setName_customer(req.getParameter("customer_name"));
  obj.setInvoice_id(Long.parseLong(req.getParameter("invoice_id")));
  obj.setCust_number(req.getParameter("customer_number"));
  obj.setTotal_open_amount(Double.parseDouble(req.getParameter("invoice_amount")));
  /*try {
   Date date=new SimpleDateFormat("yyyyMMdd").parse(req.getParameter("due_in_date"));
           // String date4=new SimpleDateFormat("yyyy-MM-dd hh:mm:ss").format(date);
            //Timestamp due_in_date=Timestamp.valueOf(date4);
            obj.setDue_in_date(date);
  } catch (ParseException e1) {
   // TODO Auto-generated catch block
   e1.printStackTrace();
  }*/
  try {
   SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
   java.util.Date date4 = sdf.parse(req.getParameter("due_in_date"));
   due_in_date = new java.sql.Date(date4.getTime());
   obj.setDue_in_date(due_in_date);
  } catch(ParseException e) {
   due_in_date = null;
  }
  String notes=req.getParameter("notes");
  String query;
  query="INSERT INTO invoice_details(business_code, cust_number, name_customer, doc_id, posting_id, business_year, invoice_currency,document_type, area_business, total_open_amount, cust_payment_terms,invoice_id,isOpen, baseline_create_date, posting_date,document_create_date, due_in_date,clear_date,notes) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
     //JDBC CONNECTION
  // JDBC driver name and database URL
     Connection conn = null;
     PreparedStatement statement=null;
    //STEP 2: Register JDBC driver
    try { 
    Class.forName("com.mysql.jdbc.Driver");
    //STEP 3: Open a connection
    conn = DriverManager.getConnection(DB_URL,USER,PASS);
    conn.setAutoCommit(false);
    statement = conn.prepareStatement(query);
    //Setting statement values
    /*
    statement.setString(1,obj.getName_customer());
    statement.setLong(2,obj.getInvoice_id());
    statement.setString(3,obj.getCustomer_number());
    statement.setDouble(4,obj.getTotal_open_amount());
    statement.setTimestamp(5,obj.getDue_in_date());
    statement.setString(6,notes);
    */
                statement.setString(1, obj.getBusiness_code());
                statement.setString(2, obj.getCust_number());
                statement.setString(3, obj.getName_customer());
                statement.setLong(4, obj.getInvoice_id());
                statement.setInt(5, obj.getPosting_id());
                statement.setInt(6, obj.getBusiness_year());
                statement.setString(7, obj.getInvoice_currency());
                statement.setString(8, obj.getDocument_type());
                statement.setString(9, obj.getArea_business());
                statement.setDouble(10,obj.getTotal_open_amount());
                statement.setString(11,obj.getCust_payment_terms());
                statement.setLong(12, obj.getInvoice_id());
                statement.setInt(13, obj.getIsOpen());
                statement.setDate(14, obj.getBaseline_create_date());
                statement.setDate(15, obj.getPosting_date());
                statement.setDate(16, obj.getDocument_create_date());
                statement.setDate(17, obj.getDue_in_date());
                statement.setDate(18, obj.getClear_date());
                statement.setString(19,notes);
    statement.addBatch();
    statement.executeBatch();
     res.getWriter().println("Invoice Added");
     //finished.
       conn.commit();
       statement.close();
       conn.close();
    }catch (IOException ex) {
            System.err.println(ex);
        } catch (SQLException ex) {
            ex.printStackTrace();
            try {
                conn.rollback();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        } catch (ClassNotFoundException e) {
   // TODO Auto-generated catch block
   e.printStackTrace();
  }
     }
}
