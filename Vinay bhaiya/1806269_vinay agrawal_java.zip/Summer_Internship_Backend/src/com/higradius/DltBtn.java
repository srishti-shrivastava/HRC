package com.higradius;




import java.io.BufferedReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.sql.*;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

//import org.json.HTTP;
//import org.json.JSONObject;

import com.google.gson.Gson;

/**
 * Servlet implementation class EditServlet
 */

public class DltBtn extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public DltBtn() {
        super();
        // TODO Auto-generated constructor stub
    }
    
    static final String JDBC_DRIVER = "com.mysql.jdbc.Driver";
    static final String DB_URL = "jdbc:mysql://localhost/h2h_internship";
    static final String USER = "root";
  	static final String PASS = "Roopa@516kiit";

    

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		response.setContentType("application/json");
	    response.setCharacterEncoding("UTF-8");
	    PrintWriter out = response.getWriter();
		
		try {
			/*String[] doc_id = request.getParameterValues("product_id_list");
			for(int i = 0;i<doc_id.length;i++) {
				System.out.println(doc_id[i]);
				System.out.println("Inside print");
			}*/
			
			String doc_id = request.getParameter("doc_id");
	    Connection conn = null;
		Statement stmt = null;
	      System.out.println("*");
		try {
			Class.forName(JDBC_DRIVER);
		    conn=DriverManager.getConnection(DB_URL,USER,PASS);
		      stmt = conn.createStatement();
		     /* for(int i=0;i<doc_id.length;i++)
		      {
		    	  String sql = "DELETE FROM invoice_details WHERE doc_id="+doc_id[i]+";";
			      stmt.executeUpdate(sql);
		      }
		      
		      */
		      String sql = "DELETE FROM invoice_details WHERE doc_id="+doc_id+";";
		      stmt.executeUpdate(sql);
		      System.out.println("*");     
		}catch(Exception e) {
			System.out.print("ERROR in array!");
			e.printStackTrace();
			
		}

		/*Gson gson = new Gson();
		String data = gson.toJson(pojo);
	    out.write(data.toString());*/
		}  
		catch(Exception e) {
			System.out.println("ERROR!!!");
		}
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//doGet(request, response);
		

		
	}

}