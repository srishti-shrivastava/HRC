package com.higradius;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.PreparedStatement;
//import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
//import java.util.HashMap;
import java.util.List;
//import java.util.Map;

import javax.servlet.ServletException;
//import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.gson.Gson;
import java.sql.Statement;
public class EditBtn  extends HttpServlet {

	
	
	static final String JDBC_DRIVER = "com.mysql.jdbc.Driver";
	static final String DB_URL = "jdbc:mysql://localhost/h2h_internship";
	// Database credentials
	static final String USER = "root";
	static final String PASS = "Roopa@516kiit";
	public static Connection conn;
	Statement stmt;
	
	
       
    /**
     * @see HttpServlet#HttpServlet()
     */
  /*  public InvoiceServlet() {
        super();
        // TODO Auto-generated constructor stub
    }*/

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		response.setContentType("application/json");
	    response.setCharacterEncoding("UTF-8");
	    PrintWriter out = response.getWriter();
		int doc_id;
		float total_open_amount;
		String notes;
		try {
		doc_id = Integer.parseInt(request.getParameter("doc_id"));
		total_open_amount = Float.parseFloat(request.getParameter("total_open_amount"));
		notes = request.getParameter("notes");
		String t = String.valueOf(total_open_amount);
		String di = String.valueOf(doc_id);
		System.out.println(total_open_amount);
		System.out.println(doc_id);
		System.out.println(notes);
		
	    Connection conn = null;
		Statement stmt = null;
	      System.out.println("***");
		try {

			Class.forName(JDBC_DRIVER);
		    conn=DriverManager.getConnection(DB_URL,USER,PASS);
		      stmt = conn.createStatement();
		      String sql = "UPDATE invoice_details SET total_open_amount="+t+",notes='"+notes+"' WHERE doc_id="+di;
		      stmt.executeUpdate(sql);
		      //ResultSet rs = stmt.executeQuery(sql);
		      //statement=conn.prepareStatement(query);
		      System.out.println("***");     
		}catch(Exception e) {
			System.out.print("ERROR!");
			e.printStackTrace();
			
		}

		/*Gson gson = new Gson();
		String data = gson.toJson(pojo);
	    out.write(data.toString());*/
		}  
		catch(Exception e) {
			System.out.println("ERROR!!!");
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//doGet(request, response);
		
		
		
	}

		
	}